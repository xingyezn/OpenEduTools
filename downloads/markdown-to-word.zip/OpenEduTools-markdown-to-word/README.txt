OpenEduTools · Markdown 转 Word

使用方法：解压整个文件夹后，双击 index.html。
名单、成绩和文本只在浏览器本地处理。
项目地址：https://github.com/xingyezn/OpenEduTools
许可证：MIT
